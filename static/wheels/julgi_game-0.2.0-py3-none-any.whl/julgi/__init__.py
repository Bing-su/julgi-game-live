from .__main__ import game
from .__version__ import __version__

__all__ = ["__version__", "game"]
